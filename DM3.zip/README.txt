# Devoir3_IFT3911

Exécuter "Main_View.java" pour lancer le logiciel.

SEULEMENT UNE PARTIE DU LOGICIEL EST IMPLÉMENTÉE.

Comme demandé dans l'énoncé, les collections d'objets sont des ArrayList passées en attributs du gestionnaire qui s'en occupe (ex : ArrayList<Client> clients dans ClientGestion).
Beaucoup de "switch.. case" utilisés pour modéliser le comportement car nous sommes partis sur l'hypothèse que ce projet n'aura pas besoin de maintenance. 
