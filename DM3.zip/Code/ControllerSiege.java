public class ControllerSiege extends AdminController {

	public void ajouterSiege() {
		// TODO - implement ControllerSiege.ajouterSiege
		throw new UnsupportedOperationException();
	}

	public void supprimerSiege() {
		// TODO - implement ControllerSiege.supprimerSiege
		throw new UnsupportedOperationException();
	}

	public void modifierSiege() {
		// TODO - implement ControllerSiege.modifierSiege
		throw new UnsupportedOperationException();
	}

}