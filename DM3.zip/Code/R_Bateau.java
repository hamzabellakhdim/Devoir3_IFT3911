public class R_Bateau extends Reservation {
}