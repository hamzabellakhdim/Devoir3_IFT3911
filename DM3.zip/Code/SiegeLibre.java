public class SiegeLibre implements SiegeEtat {
}