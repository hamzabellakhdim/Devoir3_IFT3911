public class SiegeGestion implements Gestionnaire {

	public Siege ajouter() {
		// TODO - implement SiegeGestion.ajouter
		throw new UnsupportedOperationException();
	}

	public Siege supprimer() {
		// TODO - implement SiegeGestion.supprimer
		throw new UnsupportedOperationException();
	}

	public Siege modifier() {
		// TODO - implement SiegeGestion.modifier
		throw new UnsupportedOperationException();
	}

	public void notify() {
		// TODO - implement SiegeGestion.notify
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param ModifSiege
	 */
	public void attach(int ModifSiege) {
		// TODO - implement SiegeGestion.attach
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param ModifSiege
	 */
	public void detach(int ModifSiege) {
		// TODO - implement SiegeGestion.detach
		throw new UnsupportedOperationException();
	}

}