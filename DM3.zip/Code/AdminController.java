public abstract class AdminController {
    public Object ajouter() {
		// TODO - implement ControllerCompagnie.ajouterCompagnie
		throw new UnsupportedOperationException();
	}

	public void supprimer(Object o) {
		// TODO - implement ControllerCompagnie.supprimerCompagnie
		throw new UnsupportedOperationException();
	}

	public void modifier(Object o) {
		// TODO - implement ControllerCompagnie.modifierCompagnie
		throw new UnsupportedOperationException();
	}
}