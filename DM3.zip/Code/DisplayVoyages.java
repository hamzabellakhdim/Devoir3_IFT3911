public class DisplayVoyages implements VisitVoyages {

	/**
	 * 
	 * @param v
	 */
	public void visitVols() {
	}

	/**
	 * 
	 * @param t
	 */
	public void visitTrajets() {
	}

	/**
	 * 
	 * @param i
	 */
	public void visitItineraires() {
	}

}