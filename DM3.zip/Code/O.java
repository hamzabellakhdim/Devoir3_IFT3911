public class O extends S_Paquebot {
	private float prixMult = (float)0.75;

}