public class Gare extends Location {
    public Gare(String id, String ville) {
        super(id, ville);
    }
}