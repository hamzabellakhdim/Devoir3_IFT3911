public class CompagnieNavale extends Compagnie {

    public CompagnieNavale(String id, String nom){
        super(id,nom);
    }

}