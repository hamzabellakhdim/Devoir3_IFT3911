public class CompagnieAerienne extends Compagnie {
   
    public CompagnieAerienne(String id, String nom){
        super(id,nom);
    }

}