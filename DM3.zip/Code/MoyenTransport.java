public abstract class MoyenTransport {

	protected String idMoyenTransport;
	protected String type;
	protected int nb_sections;

	public Section[] getSection() {
		// TODO - implement MoyenTransport.getSection
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param classe
	 * @param debut
	 * @param fin
	 */
	public Section creerSection(Section classe, int debut, int fin) {
		// TODO - implement MoyenTransport.creerSection
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param classe
	 * @param debut
	 * @param fin
	 */
	public void supprimerSection(Section classe, int debut, int fin) {
		// TODO - implement MoyenTransport.supprimerSection
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param classe
	 * @param debut
	 * @param fin
	 */
	public Section modifierSection(Section classe, int debut, int fin) {
		// TODO - implement MoyenTransport.modifierSection
		throw new UnsupportedOperationException();
	}

}