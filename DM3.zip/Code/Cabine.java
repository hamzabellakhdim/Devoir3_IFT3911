public class Cabine extends Siege {
}