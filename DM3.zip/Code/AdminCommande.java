public abstract interface AdminCommande {

	boolean execute();

	boolean rollback();

}