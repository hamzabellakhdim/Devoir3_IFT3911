public class SiegeA extends Siege {
}