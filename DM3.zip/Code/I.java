public class I extends S_Paquebot {

	private float prixMult = (float)0.5;

}