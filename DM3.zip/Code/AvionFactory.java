public class AvionFactory extends AbstractTransportFactory {

	public Avion create() {
		// TODO - implement AvionFactory.create
		throw new UnsupportedOperationException();
	}

}