public class PremiereT extends S_Train {
	private float prixMult = (float)1.0;

}