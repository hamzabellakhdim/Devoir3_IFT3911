public class EconomiePremium extends S_Avion {

	private float prixMult = (float)0.5;

}