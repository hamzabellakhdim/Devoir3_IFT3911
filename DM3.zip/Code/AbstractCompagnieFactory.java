public abstract class AbstractCompagnieFactory {

	public abstract Object create();

}