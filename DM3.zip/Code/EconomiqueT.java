public class EconomiqueT extends S_Train {

	private float prixMult = (float)0.5;

}