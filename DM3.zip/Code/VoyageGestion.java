import Gestionnaire.*;

public class VoyageGestion implements supprimer {

	public Voyage ajouter() {
		// TODO - implement VoyageGestion.ajouter
		throw new UnsupportedOperationException();
	}

	public Voyage supprimer() {
		// TODO - implement VoyageGestion.supprimer
		throw new UnsupportedOperationException();
	}

	public Voyage modifier() {
		// TODO - implement VoyageGestion.modifier
		throw new UnsupportedOperationException();
	}

	public void notify() {
		// TODO - implement VoyageGestion.notify
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param ModifVoyage
	 */
	public void attach(int ModifVoyage) {
		// TODO - implement VoyageGestion.attach
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param ModifVoyage
	 */
	public void detach(int ModifVoyage) {
		// TODO - implement VoyageGestion.detach
		throw new UnsupportedOperationException();
	}

}