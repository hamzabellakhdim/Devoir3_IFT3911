public enum Position {
	aile,
	fenetre
}