public class SiegeT extends Siege {
}