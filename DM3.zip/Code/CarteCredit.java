import java.util.Date;

public class CarteCredit {

	private String idCC;
	private long numeroCarte;
	private String nomDetenteur;
	private int codeSecret;
	private Date dateExpiration;

}