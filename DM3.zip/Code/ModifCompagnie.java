public class ModifCompagnie implements ModifBase {

	public void update() {
		// TODO - implement ModifCompagnie.update
		throw new UnsupportedOperationException();
	}

}