public class SiegeReserve implements SiegeEtat {
}