public class ModifReservation implements ModifBase {

	public void update() {
		// TODO - implement ModifReservation.update
		throw new UnsupportedOperationException();
	}

}