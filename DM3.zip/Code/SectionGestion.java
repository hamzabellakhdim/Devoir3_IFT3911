import Gestionnaire.*;

public class SectionGestion implements attach {

	public Section ajouter() {
		// TODO - implement SectionGestion.ajouter
		throw new UnsupportedOperationException();
	}

	public Section supprimer() {
		// TODO - implement SectionGestion.supprimer
		throw new UnsupportedOperationException();
	}

	public Section modifier() {
		// TODO - implement SectionGestion.modifier
		throw new UnsupportedOperationException();
	}

	public void notify() {
		// TODO - implement SectionGestion.notify
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param ModifSection
	 */
	public void attach(int ModifSection) {
		// TODO - implement SectionGestion.attach
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param ModifSection
	 */
	public void detach(int ModifSection) {
		// TODO - implement SectionGestion.detach
		throw new UnsupportedOperationException();
	}

}