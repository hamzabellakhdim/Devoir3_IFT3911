public class Paiement {

	protected double prix;
	protected Date datePaiement;
	protected string idClient;
	protected string idCC;

	public void payer() {
		// TODO - implement Paiement.payer
		throw new UnsupportedOperationException();
	}

}