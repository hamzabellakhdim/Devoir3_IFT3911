public class PaquebotFactory extends AbstractTransportFactory {

	public Paquebot create() {
		// TODO - implement PaquebotFactory.create
		throw new UnsupportedOperationException();
	}

}