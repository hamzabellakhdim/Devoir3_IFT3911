public abstract class AbstractLocationsFactory {

	public abstract Object create();

}