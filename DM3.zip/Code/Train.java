public class Train extends MoyenTransport {
}