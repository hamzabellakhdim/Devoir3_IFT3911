public abstract class Compagnie {

	protected String idCompagnie;
	protected String nom;

	protected Compagnie(String id, String nom){
		this.idCompagnie = id;
		this.nom = nom;
	}

}