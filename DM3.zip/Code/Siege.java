public abstract class Siege {

	private char colonne;
	private int rangee;

	public EtatSiege verifierEtat() {
		// TODO - implement Siege.verifierEtat
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param etat
	 */
	public void modifierEtat(EtatSiege etat) {
		// TODO - implement Siege.modifierEtat
		throw new UnsupportedOperationException();
	}

}