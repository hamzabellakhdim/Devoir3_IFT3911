public class Aeroport extends Location {

    public Aeroport(String id, String ville) {
        super(id, ville);
    }
    
}