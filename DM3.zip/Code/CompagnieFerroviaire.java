public class CompagnieFerroviaire extends Compagnie {

    public CompagnieFerroviaire(String id, String nom){
        super(id,nom);
    }

}