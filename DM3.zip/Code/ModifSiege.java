public class ModifSiege implements ModifBase {

	public void update() {
		// TODO - implement ModifSiege.update
		throw new UnsupportedOperationException();
	}

}