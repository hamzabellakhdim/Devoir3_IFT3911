public class ModifSection implements ModifBase {

	public void update() {
		// TODO - implement ModifSection.update
		throw new UnsupportedOperationException();
	}

}