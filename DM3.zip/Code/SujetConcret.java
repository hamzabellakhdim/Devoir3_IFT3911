public class SujetConcret implements Sujet {
    
    public void attach(ModifBase m) {
        System.out.println("\n\n\n\nObservateur attaché");
    }
}