public class R_Avion extends Reservation {
}