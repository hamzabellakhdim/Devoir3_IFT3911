public class ControllerMoyenTransport extends AdminController {

	public void ajouterMoyenTransport() {
		// TODO - implement ControllerMoyenTransport.ajouterMoyenTransport
		throw new UnsupportedOperationException();
	}

	public void supprimerMoyenTransport() {
		// TODO - implement ControllerMoyenTransport.supprimerMoyenTransport
		throw new UnsupportedOperationException();
	}

	public void modifierMoyenTransport() {
		// TODO - implement ControllerMoyenTransport.modifierMoyenTransport
		throw new UnsupportedOperationException();
	}

}