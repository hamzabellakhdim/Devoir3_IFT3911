public abstract class AbstractTransportFactory {

	public abstract Object create();

}