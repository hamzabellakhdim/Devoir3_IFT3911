public class ControllerReservation extends ClientController {

	/**
	 * 
	 * @param siege
	 * @param idVoyage
	 * @param depart
	 * @param retour
	 */
	public void reserver(Siege siege, String idVoyage, Date depart, Date retour) {
		// TODO - implement ControllerReservation.reserver
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param idReservation
	 * @param idClient
	 * @param prix
	 */
	public void payerReservation(String idReservation, String idClient, float prix) {
		// TODO - implement ControllerReservation.payerReservation
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param idReservation
	 */
	public void modifierReservation(String idReservation) {
		// TODO - implement ControllerReservation.modifierReservation
		throw new UnsupportedOperationException();
	}

}