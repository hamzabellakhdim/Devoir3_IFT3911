public class Avion extends MoyenTransport {
}