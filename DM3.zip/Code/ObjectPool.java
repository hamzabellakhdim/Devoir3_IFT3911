public class ObjectPool {

	public ObjectPool getInstance() {
		// TODO - implement ObjectPool.getInstance
		throw new UnsupportedOperationException();
	}

	public MoyenTransport acquireReusable() {
		// TODO - implement ObjectPool.acquireReusable
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param mt
	 */
	public void releaseReusable(MoyenTransport mt) {
		// TODO - implement ObjectPool.releaseReusable
		throw new UnsupportedOperationException();
	}

}