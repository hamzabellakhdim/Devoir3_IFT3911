public abstract class S_Paquebot extends Section {
}