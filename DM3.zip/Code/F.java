public class F extends S_Paquebot {

	private float prixMult = (float)0.9;

}