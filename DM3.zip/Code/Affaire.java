public class Affaire extends S_Avion {

	private float prixMult = (float) 0.75;

}