public abstract class Section {

	protected String idSection;
	protected String nom;
	protected double prix;
	protected int nbSection;

	/**
	 * 
	 * @param siege
	 */
	public Siege ajouterSiege(Siege siege) {
		// TODO - implement Section.ajouterSiege
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param siege
	 */
	public void supprimerSiege(Siege siege) {
		// TODO - implement Section.supprimerSiege
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param siege
	 */
	public Siege modifierSiege(Siege siege) {
		// TODO - implement Section.modifierSiege
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param siege
	 */
	public Siege getSiege(Siege siege) {
		// TODO - implement Section.getSiege
		throw new UnsupportedOperationException();
	}

}