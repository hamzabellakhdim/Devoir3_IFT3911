public class V_en_train extends Voyage {


	public V_en_train(String idSiege, String idSection, String idmoyenTrans, boolean etat, String id, int duree, double prix, String lieuDep, String lieuArr, long dep, long arr){
		super(idSiege, idSection, idmoyenTrans, etat, id, duree, prix, lieuDep, lieuArr, dep, arr);
	}
	/**
	 * 
	 * @param v
	 */
	public void accept(VisitVoyages v) {
		// TODO - implement V_en_train.accept
		throw new UnsupportedOperationException();
	}

	public void displayInfos() {
		// TODO - implement V_en_train.displayInfos
		throw new UnsupportedOperationException();
	}

}