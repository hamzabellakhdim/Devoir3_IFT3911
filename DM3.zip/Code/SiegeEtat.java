public interface SiegeEtat {
}