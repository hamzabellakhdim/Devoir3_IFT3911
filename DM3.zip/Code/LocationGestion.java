import java.util.Date;

public class LocationGestion implements Gestionnaire {

	private LocationsSingleton ls;

	public Location ajouter() {
		// TODO - implement LocationGestion.ajouter
		throw new UnsupportedOperationException();
	}

	public Location supprimer() {
		// TODO - implement LocationGestion.supprimer
		throw new UnsupportedOperationException();
	}

	public Location modifier() {
		// TODO - implement LocationGestion.modifier
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param villeA
	 * @param dateD
	 */
	public void chercherVoyage(Location villeA, Date dateD) {
		// TODO - implement LocationGestion.chercherVoyage
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param villeD
	 */
	public void filterByDestination(Location villeD) {
		// TODO - implement LocationGestion.filterByDestination
		throw new UnsupportedOperationException();
	}

	@Override
	public void attach(int ModifBase) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void detach(int ModifBase) {
		// TODO Auto-generated method stub
		
	}

}