public interface Sujet {

	/**
	 * 
	 * @param ModifBase
	 */
	public void attach(ModifBase m);

	/**
	 * 
	 * @param ModifBase
	 */
	public void detach(ModifBase m);

	public void notify_();

}