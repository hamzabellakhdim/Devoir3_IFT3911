public class R_Train extends Reservation {
}