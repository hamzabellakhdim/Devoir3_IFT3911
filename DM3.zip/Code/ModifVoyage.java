public class ModifVoyage implements ModifBase {

	public void update() {
		// TODO - implement ModifVoyage.update
		throw new UnsupportedOperationException();
	}

}