public class ModifMoyenTransport implements ModifBase {

	public void update() {
		// TODO - implement ModifMoyenTransport.update
		throw new UnsupportedOperationException();
	}

}