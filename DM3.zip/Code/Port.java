public class Port extends Location {
    public Port(String id, String ville) {
        super(id, ville);
    }
}