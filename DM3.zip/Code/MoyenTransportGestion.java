import Gestionnaire.*;

public class MoyenTransportGestion extends ObjectPool implements modifier {

	private TransportSingleton ts;

	public MoyenTransport ajouter() {
		// TODO - implement MoyenTransportGestion.ajouter
		throw new UnsupportedOperationException();
	}

	public MoyenTransport supprimer() {
		// TODO - implement MoyenTransportGestion.supprimer
		throw new UnsupportedOperationException();
	}

	public MoyenTransport modifier() {
		// TODO - implement MoyenTransportGestion.modifier
		throw new UnsupportedOperationException();
	}

	public void notify() {
		// TODO - implement MoyenTransportGestion.notify
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param ModifMoyenTransport
	 */
	public void attach(int ModifMoyenTransport) {
		// TODO - implement MoyenTransportGestion.attach
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param ModifMoyenTransport
	 */
	public void detach(int ModifMoyenTransport) {
		// TODO - implement MoyenTransportGestion.detach
		throw new UnsupportedOperationException();
	}

}