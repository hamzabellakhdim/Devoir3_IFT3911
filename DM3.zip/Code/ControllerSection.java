public class ControllerSection extends AdminController {

	public void ajouterSection() {
		// TODO - implement ControllerSection.ajouterSection
		throw new UnsupportedOperationException();
	}

	public void supprimerSection() {
		// TODO - implement ControllerSection.supprimerSection
		throw new UnsupportedOperationException();
	}

	public void modifierSection() {
		// TODO - implement ControllerSection.modifierSection
		throw new UnsupportedOperationException();
	}

}