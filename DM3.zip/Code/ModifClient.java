public class ModifClient implements ModifBase {

	public void update() {}

}