public class Paquebot extends MoyenTransport {
}