public class Premiere extends S_Avion {

	private float prixMult = (float)1.0;

}