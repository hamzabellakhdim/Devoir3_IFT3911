public class SiegePaye implements SiegeEtat {
}