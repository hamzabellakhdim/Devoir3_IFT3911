public class GareFactory extends AbstractLocationsFactory {

	public Gare create() {
		// TODO - implement GareFactory.create
		throw new UnsupportedOperationException();
	}

}