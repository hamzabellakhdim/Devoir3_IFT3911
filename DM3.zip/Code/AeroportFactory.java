public class AeroportFactory extends AbstractLocationsFactory {

	public Aeroport create() {
		// TODO - implement AeroportFactory.create
		throw new UnsupportedOperationException();
	}

}