public class ListeVoyages {

	/**
	 * 
	 * @param v
	 */
	public void accept(DisplayVoyages v) {
		
	}

}