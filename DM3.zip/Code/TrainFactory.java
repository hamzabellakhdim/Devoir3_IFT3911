public class TrainFactory extends AbstractTransportFactory {

	public Train create() {
		// TODO - implement TrainFactory.create
		throw new UnsupportedOperationException();
	}

}