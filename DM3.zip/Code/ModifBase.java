public abstract interface ModifBase {

	void update();

}