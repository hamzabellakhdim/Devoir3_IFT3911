public class ReservationGestion implements Gestionnaire {

	public Reservation ajouter() {
		// TODO - implement ReservationGestion.ajouter
		throw new UnsupportedOperationException();
	}

	public Reservation supprimer() {
		// TODO - implement ReservationGestion.supprimer
		throw new UnsupportedOperationException();
	}

	public Reservation modifier() {
		// TODO - implement ReservationGestion.modifier
		throw new UnsupportedOperationException();
	}

	public void notify() {
		// TODO - implement ReservationGestion.notify
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param ModifReservation
	 */
	public void attach(int ModifReservation) {
		// TODO - implement ReservationGestion.attach
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param ModifReservation
	 */
	public void detach(int ModifReservation) {
		// TODO - implement ReservationGestion.detach
		throw new UnsupportedOperationException();
	}

}