public abstract class S_Train extends Section {
}