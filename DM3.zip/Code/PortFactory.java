public class PortFactory extends AbstractLocationsFactory {

	public Port create() {
		// TODO - implement PortFactory.create
		throw new UnsupportedOperationException();
	}

}