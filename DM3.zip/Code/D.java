public class D extends S_Paquebot {

	private float prixMult = (float)1.0;

}